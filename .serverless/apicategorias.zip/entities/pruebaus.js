module.exports ={
    name: 'Pruebaus',
    columns: {
        id: {
            primary: true,
            generated: true,
            type: "int"
            
        },
        name:{
            type: "varchar"
        }
    }
}