module.exports = {
  name: "Pruebaus",
  columns: {
    id: {
      primary: true,
      type: "int",
      generated: true
    },
    name: {
      type: "varchar"
    },
  },
};
