const userpruebaController = require("./userprueba.controller");

module.exports=(api,opts)=>{
    api.get("/", userpruebaController.getusersprueba);

    api.post("/", userpruebaController.createuserprueba);
    
    api.post("/signup", userpruebaController.signup);

    api.post("/login", userpruebaController.login);

    api.post("/mailprueba", userpruebaController.mailprueba);
}