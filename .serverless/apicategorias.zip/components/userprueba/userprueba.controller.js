const userpruebaService = require("./userprueba.service");
const response=require('../../helpers/responseFormat')
class UserpruebaController{
    async getusersprueba(req,res){
        let usersprueba= await userpruebaService.get();
        if(usersprueba.error){
            return res.json({msg: 'Error'})
        }
        return response(res,200, usersprueba);
    }

    async createuserprueba(req,res){
        
        let userprueba= await userpruebaService.create(req.body);
        
        return response(res,200,userprueba)
    }
}

const userpruebaController = new UserpruebaController();
module.exports = userpruebaController;